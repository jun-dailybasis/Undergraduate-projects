package com.example.zuryuk.assignment2;
import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class WeatherService extends Service {
    //Strings
    //Service
    public static final String BROADCAST_BACKGROUND_SERVICE_RESULT = "com.example.zuryuk.assignment2.BROADCAST_BACKGROUND_SERVICE_RESULT";
    private static final String LOG = "WeatherService";
    private static final String ERROR = "Error occurred";
    private static final String SUCCESS = "New weather data";
    //Request
    private static final String WEATHER_API_KEY = "185d095eff82c5fa288368f898d02543";
    private static final long CITY_ID_AARHUS = 2624652;
    private static final String WEATHER_API_CALL = "http://api.openweathermap.org/data/2.5/forecast/city?id=" + CITY_ID_AARHUS + "&APPID=" + WEATHER_API_KEY + "&UNITS=metric";
    //Variables
    RequestQueue queue;
    private Weather weather;
    private WeatherDB weatherHandler;
    private boolean started = false;
    private long wait = 30 * 1000; // 30 mins in ms
    private final IBinder mBinder = new MyBinder();

    public WeatherService() { //Constructor
    }

    @Override
    public void onCreate() {
        super.onCreate();
        weatherHandler = new WeatherDB(this);
        Log.d(LOG, "Background service created");
    }
    @Override
    public IBinder onBind(Intent intent){
        return mBinder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(!started && intent!=null) {
            Log.d(LOG, "Background service started");
            started = true;
            getWeatherData();
        }
        return START_STICKY; // On stop start again
    }

    private void getWeatherData(){

        AsyncTask<Object, Object, String> task = new AsyncTask<Object, Object, String>() {
            @Override
            protected String doInBackground(Object[] params) {
                try {
                    Log.d(LOG, "Fetching data...");
                    requestJSON();
                    Thread.sleep(wait);
                } catch (Exception e) {
                    e.printStackTrace();
                    return ERROR;
                }
                return SUCCESS;
            }


            @Override
            protected void onPostExecute(String stringResult) {
                super.onPostExecute(stringResult);
                broadcastTaskResult();
                if(started){
                    getWeatherData();
                }
            }
        };
        task.execute();
    }

    private void broadcastTaskResult(){
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction(BROADCAST_BACKGROUND_SERVICE_RESULT);
        broadcastIntent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
        Log.d(LOG, "Broadcasting...");
        sendBroadcast(broadcastIntent);
    }

    @Override
    public void onDestroy() {
        started = false;
        Log.d(LOG,"Background service destroyed");
        super.onDestroy();
    }
    private void requestJSON() {
        if (queue == null)
            queue = Volley.newRequestQueue(this);

        String url = WEATHER_API_CALL;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        parseJSON(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOG, "Volley error");
                error.printStackTrace();
            }
        });

        queue.add(stringRequest);

    }
    public void parseJSON(String jsonResponse){

        try {
            JSONObject cityWeatherJson = new JSONObject(jsonResponse);

            JSONObject city = cityWeatherJson.getJSONObject("city");
            String cityName = city.getString("name");
            JSONArray measurements = cityWeatherJson.getJSONArray("list");
            String weatherString = measurements.getJSONObject(0).getJSONArray("weather").getJSONObject(0).getString("main");
            String descriptionString = measurements.getJSONObject(0).getJSONArray("weather").getJSONObject(0).getString("description");
            String tempString = measurements.getJSONObject(0).getJSONObject("main").getString("temp");
            String timeString = measurements.getJSONObject(0).getString("dt_txt");
            String iconCode = measurements.getJSONObject(0).getJSONArray("weather").getJSONObject(0).getString("icon");
            String iconURL = "http://openweathermap.org/img/w/" + iconCode +".png";
            weatherHandler = new WeatherDB(this);
            weather = new Weather(1, descriptionString, timeString, tempString);
            weather.print();
            weatherHandler.putWeather(weather);
            Weather a = weatherHandler.readWeather();
            a.print();
            System.out.println(cityName + "\n" + descriptionString + "\n" + timeString);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public class MyBinder extends Binder {
        WeatherService getService(){
            return WeatherService.this;
        }
    }
    public Weather getCurrentWeather(){
        Weather weather = weatherHandler.readWeather();
        return weather;
    }
    public ArrayList<Weather> getPastWeather(){
        ArrayList<Weather> weatherList = weatherHandler.readPastWeather();
        return weatherList;
    }
}