package com.example.zuryuk.assignment2;


/**
 * Created by Pierre BJX on 27/09/2016.
 */

public class Weather {

    private long ID;
    private String desc;
    private String timestamp;
    private String temp;

    public Weather(long ID, String temp, String desc, String timestamp){
        this.ID = ID;
        this.desc = desc;
        this.timestamp = timestamp;
        this.temp = temp;
    }
    public Weather(){
        this.ID = 0;
        this.desc = "desc";
        this.timestamp = "timestamp";
        this.temp = "temp";
    }
    public void print() {
        System.out.println(ID + "\n" + desc + "\n" + timestamp + "\n" + temp);
    }

    public void setID(int ID){
        this.ID = ID;
    }

    public void setDesc(String desc){
        this.desc = desc;
    }

    public void setTimestamp(String timestamp){
        this.timestamp = timestamp;
    }

    public void setTemp (String temp){
        this.temp = temp;
    }

    public long getID(){
        return ID;
    }

    public String getDesc(){
        return desc;
    }

    public String getTimestamp(){
        return timestamp;
    }

    public String getTemp(){
        return temp;
    }
    public String giveWeather(){
        return ID + desc + timestamp + temp;
    }
}

