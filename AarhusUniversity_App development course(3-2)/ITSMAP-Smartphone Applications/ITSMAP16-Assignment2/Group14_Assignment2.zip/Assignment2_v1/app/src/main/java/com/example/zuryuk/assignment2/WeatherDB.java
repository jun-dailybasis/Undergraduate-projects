package com.example.zuryuk.assignment2;

/**
 * Created by Pierre BJX on 27/09/2016.
 */


import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;

import java.util.ArrayList;
import java.util.List;

import static java.security.AccessController.getContext;

public class WeatherDB extends SQLiteOpenHelper{

    public static final int DATABASE_VERSION = 1;
    public static final String WEATHER_ID = "ID";
    public static final String WEATHER_DESC = "desc";
    public static final String WEATHER_TEMP = "temp";
    public static final String WEATHER_TIMESTAMP = "timestamp";
    public static final String WEATHER_TABLE_NAME = "WEATHER_INFO";
    public static final String WEATHER_ORDER = WEATHER_ID + " DESC";
    public static final String WEATHER_LIMIT = "48";

    public static final String WEATHER_TABLE_CREATE =
            " CREATE TABLE " + WEATHER_TABLE_NAME + " (" +
                    WEATHER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                    WEATHER_TEMP + " TEXT, " +
                    WEATHER_DESC + " TEXT, " +
                    WEATHER_TIMESTAMP + " TEXT);";

    private static final String WEATHER_TABLE_DELETE = "DROP TABLE IF EXISTS " + WEATHER_TABLE_NAME;

    public WeatherDB(Context context){
        super(context, WEATHER_TABLE_NAME, null, DATABASE_VERSION);
    }
    public void test() {
        System.out.println("Toimii");
    }

    public void onCreate(SQLiteDatabase db){
        db.execSQL(WEATHER_TABLE_CREATE);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL(WEATHER_TABLE_CREATE);
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    public void putWeather(Weather weather) { //insert weather object into database
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WEATHER_TEMP, weather.getTemp());
        values.put(WEATHER_DESC, weather.getDesc());
        values.put(WEATHER_TIMESTAMP, weather.getTimestamp());

        db.insert(WEATHER_TABLE_NAME, null, values);
        db.close();
    }

    public Weather readWeather(){ //return current weather

        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = new String[] { WEATHER_ID,  WEATHER_TEMP, WEATHER_DESC, WEATHER_TIMESTAMP};
        Cursor c = db.query(WEATHER_TABLE_NAME, columns, null, null, null, null, WEATHER_ORDER);
        int iRow = c.getColumnIndex(WEATHER_ID);
        int iTemp = c.getColumnIndex(WEATHER_TEMP);
        int iDesc = c.getColumnIndex(WEATHER_DESC);
        int iTime = c.getColumnIndex(WEATHER_TIMESTAMP);
        c.moveToFirst();
        Weather weather = new Weather(c.getLong(iRow), c.getString(iTemp), c.getString(iDesc), c.getString(iTime));
        c.close();
        db.close();
        return weather;
    }
    public ArrayList<Weather> readPastWeather(){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = new String[] { WEATHER_ID,  WEATHER_TEMP, WEATHER_DESC, WEATHER_TIMESTAMP};
        Cursor c = db.query(WEATHER_TABLE_NAME, columns, null, null, null, null, WEATHER_ORDER, WEATHER_LIMIT);
        ArrayList<Weather> weatherList = new ArrayList<Weather>();
        Weather weather;
        int iRow = c.getColumnIndex(WEATHER_ID);
        int iTemp = c.getColumnIndex(WEATHER_TEMP);
        int iDesc = c.getColumnIndex(WEATHER_DESC);
        int iTime = c.getColumnIndex(WEATHER_TIMESTAMP);
        c.moveToFirst();
        c.moveToNext(); // Start current weather + 1
        for (c.getPosition(); !c.isAfterLast(); c.moveToNext()){
            weather = new Weather(c.getLong(iRow), c.getString(iTemp), c.getString(iDesc), c.getString(iTime));
            weatherList.add(weather);
        }
        c.close();
        db.close();
        return weatherList;
    }


}
