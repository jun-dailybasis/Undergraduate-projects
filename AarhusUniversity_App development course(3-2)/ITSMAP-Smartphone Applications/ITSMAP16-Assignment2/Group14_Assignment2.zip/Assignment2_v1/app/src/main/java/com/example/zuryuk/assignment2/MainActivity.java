package com.example.zuryuk.assignment2;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/* Code inspired by
http://stackoverflow.com/questions/21974587/service-that-runs-every-minute
https://www.youtube.com/watch?v=ahE8bQRD4f0
https://www.youtube.com/watch?v=-sBxmjrSn34
http://stackoverflow.com/questions/8230606/android-run-thread-in-service-every-x-seconds
http://stackoverflow.com/questions/28062440/how-to-run-service-in-background-every-10-minute
http://stackoverflow.com/questions/8321443/how-to-start-service-using-alarm-manager-in-android
ITSMAP 16-2 MATERIAL
https://www.youtube.com/watch?v=0c4jRCm353c
*/
public class MainActivity extends AppCompatActivity {
    // Elements
    private Button updButton;
    TextView currWeather;
    TextView currTemp;
    //Variables
    boolean isBound = false;
    //Broadcast
    IntentFilter filter;
    //Other
    WeatherService weatherService;
    WeatherDB weatherHandler;
    private ArrayList<Weather> data = null;
    private WeatherAdapter adapter = null;
    private ListView listview = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        filter = new IntentFilter();
        filter.addAction("com.example.zuryuk.assignment2.BROADCAST_BACKGROUND_SERVICE_RESULT");
        registerReceiver(receiver, filter);
        updButton = (Button) findViewById(R.id.buttonRefresh);
        updButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                UpdateCurrent();
                UpdatePast();

            }
        });
        //Current weather
        currWeather = (TextView) findViewById(R.id.editWeather);
        currTemp = (TextView) findViewById(R.id.editCelsius);
        //Service
        weatherHandler = new WeatherDB(this);
        Intent weatherIntent = new Intent(this, WeatherService.class);
        startService(weatherIntent);
        bindService(weatherIntent, weatherConn, Context.BIND_AUTO_CREATE);
    }

    private ServiceConnection weatherConn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            WeatherService.MyBinder binder = (WeatherService.MyBinder) service;
            weatherService = binder.getService();
            isBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };

    public void UpdateCurrent() {
        Weather weather = weatherService.getCurrentWeather();
        currWeather.setText(weather.getTemp());
        currTemp.setText(weather.getTimestamp() + (char) 0x00B0 + "C");
    }

    public void UpdatePast() {
        ArrayList<Weather> weatherList = weatherService.getPastWeather();
        weatherList.get(1).print();
        listview = (ListView) findViewById(R.id.lv_weather);
        adapter = new WeatherAdapter(MainActivity.this, R.layout.past_weather, weatherList);
        listview = (ListView) findViewById(R.id.lv_weather);
        listview.setAdapter(adapter);
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(action.equals("com.example.zuryuk.assignment2.BROADCAST_BACKGROUND_SERVICE_RESULT")){
            UpdateCurrent();
            UpdatePast();}
        }
    };
}