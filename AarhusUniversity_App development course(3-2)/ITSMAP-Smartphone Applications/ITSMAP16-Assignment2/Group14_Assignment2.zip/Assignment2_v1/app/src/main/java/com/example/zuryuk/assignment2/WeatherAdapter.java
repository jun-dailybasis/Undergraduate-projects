package com.example.zuryuk.assignment2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class WeatherAdapter extends BaseAdapter {
    private Context mContext = null;
    private int layout;
    private ArrayList<Weather> data = null;
    private LayoutInflater inflater = null;

    public WeatherAdapter(Context context, int custom_layout , ArrayList<Weather> data){
        this.mContext=context;
        this.layout=custom_layout;
        this.data= data;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position).getID();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(convertView == null) {
            convertView = inflater.inflate(this.layout, parent, false);
        }

        TextView timestamp = (TextView) convertView.findViewById(R.id.timestamp);
        TextView weather = (TextView) convertView.findViewById(R.id.pastWeather);
        ImageView icon = (ImageView) convertView.findViewById(R.id.imageWeather);
        TextView cel = (TextView) convertView.findViewById(R.id.pastCel);

        timestamp.setText(data.get(position).getTimestamp()+ (char) 0x00B0 + "C");
        //icon.setImageResource(data.get(position).getID());
        weather.setText(data.get(position).getDesc());
        cel.setText(data.get(position).getTemp());

        return convertView;
    }
}
